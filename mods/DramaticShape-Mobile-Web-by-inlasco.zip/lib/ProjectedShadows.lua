-- Web/iPhone ground shadows built from world-space geometric proxies.
--
-- This module is deliberately independent from ShadowMap. It creates no
-- canvas, depth texture, packed depth, light frustum or framebuffer pass.
-- A caster is only an axis-aligned footprint plus a bottom/top height. The
-- footprint at the receiver height and the footprint shifted by the sun
-- shear at the caster top form one convex silhouette; that polygon is then
-- clipped against the map's real horizontal ground cells.
--
-- Static geometry is cached by map analysis identity plus a quantised sun
-- direction. It is generated cooperatively after terrain publication.
-- Characters share one small stream mesh, rebuilt only when a pose or the
-- quantised sun changes. Camera state is absent from every key and formula.

local V = ...

local ModSetting = V.require("ModSetting")
local Voxel3D = V.require("Voxel3D")
local Mat4 = V.require("Mat4")
local Structures = V.require("Structures")
local DayNight = V.require("DayNight")
local Budget = V.require("BuildBudget")

local ProjectedShadows = {}

local WEB_RUNTIME = love and love.system and love.system.getOS
                    and love.system.getOS() == "Web"

ProjectedShadows.setting = ModSetting.new(
  "projected_shadows", "G-SHADOW",
  { false, true }, { "OFF", "ON" })

-- A quarter world pixel is the existing proven decal offset: small enough
-- to remain attached to the floor, large enough to win a lequal comparison
-- against the terrain's exact y=0 plane after the same world curve is applied.
ProjectedShadows.EPS = 0.25

-- The daylight rig already clamps shadow displacement to twice caster
-- height. Capping proxy height bounds both distant-neighbour culling and a
-- malformed/custom structure without changing ordinary Kanto buildings.
ProjectedShadows.MAX_CASTER_HEIGHT = 96
ProjectedShadows.SUN_QUANT = 16
ProjectedShadows.BLOCK_VERTICES = 2046

local cache = {}             -- map id -> last published record
local pending = {}           -- map id -> newest requested job
local jobs = {}              -- cooperative FIFO
local live = {}
local prewarmRetain = {}     -- map id -> live-set changes still to survive
local white = nil
local failed, failureReason = false, nil
local dynMesh, dynCapacity, dynCount, dynSignature = nil, 0, 0, nil
local dynVerts = {}
local clock = (love and love.timer and love.timer.getTime) or os.clock
local maxPump, totalBuilds = 0, 0

local function release(mesh)
  if mesh then Voxel3D.releaseMesh(mesh) end
end

local function fail(reason)
  if failed then return false end
  failed = true
  failureReason = tostring(reason or "unknown projected-shadow error")
  for _, rec in pairs(cache) do release(rec.mesh) end
  cache, pending, jobs = {}, {}, {}
  release(dynMesh)
  dynMesh, dynCapacity, dynCount, dynSignature = nil, 0, 0, nil
  if white and white.release then pcall(white.release, white) end
  white = false
  print("[warn] geometric shadows disabled for this session: "
        .. failureReason)
  return false
end

function ProjectedShadows.supported()
  return WEB_RUNTIME and not failed and love and love.graphics
         and love.graphics.newMesh and love.graphics.setDepthMode
         and Voxel3D.drawProjectedShadow
end

function ProjectedShadows.enabled()
  return ProjectedShadows.supported()
         and ProjectedShadows.setting:get() == true
end

function ProjectedShadows.failureReason()
  return failureReason
end

local function roundTo(v, q)
  local n = v * q
  if n >= 0 then return math.floor(n + 0.5) / q end
  return math.ceil(n - 0.5) / q
end

function ProjectedShadows.quantizeDirection(kx, kz)
  local q = ProjectedShadows.SUN_QUANT
  return roundTo(kx or 0, q), roundTo(kz or 0, q)
end

-- The same state and function the existing lighting rig reads. No second
-- solar model exists here; only the expensive static geometry is quantised.
function ProjectedShadows.direction()
  local kx, kz = DayNight.shearAt(DayNight.rigTime())
  return ProjectedShadows.quantizeDirection(kx, kz)
end

function ProjectedShadows.extension()
  if not ProjectedShadows.enabled() then return 0, 0 end
  local kx, kz = ProjectedShadows.direction()
  return math.abs(kx) * ProjectedShadows.MAX_CASTER_HEIGHT,
         math.abs(kz) * ProjectedShadows.MAX_CASTER_HEIGHT
end

-- ------------------------------------------------------------------ math --

local function copyCaster(c, ox, oz)
  return {
    x0 = c.x0 + (ox or 0), x1 = c.x1 + (ox or 0),
    z0 = c.z0 + (oz or 0), z1 = c.z1 + (oz or 0),
    baseY = c.baseY or 0, topY = c.topY,
    kind = c.kind,
  }
end

ProjectedShadows.offsetCaster = copyCaster

-- Projection along the real ray (kx, -1, kz). `kx`/`kz` are already the
-- displacement per world pixel of height exposed by DayNight.shearAt.
function ProjectedShadows.projectPoint(p, receiverY, kx, kz)
  local d = p[2] - receiverY
  return { p[1] + kx * d, receiverY + ProjectedShadows.EPS,
           p[3] + kz * d }
end

local function cross(o, a, b)
  return (a[1] - o[1]) * (b[2] - o[2])
         - (a[2] - o[2]) * (b[1] - o[1])
end

local function convexHull(points)
  table.sort(points, function(a, b)
    return a[1] < b[1] or (a[1] == b[1] and a[2] < b[2])
  end)
  local unique = {}
  for _, p in ipairs(points) do
    local q = unique[#unique]
    if not q or p[1] ~= q[1] or p[2] ~= q[2] then
      unique[#unique + 1] = p
    end
  end
  if #unique <= 2 then return unique end
  local lower = {}
  for _, p in ipairs(unique) do
    while #lower >= 2
      and cross(lower[#lower - 1], lower[#lower], p) <= 0 do
      lower[#lower] = nil
    end
    lower[#lower + 1] = p
  end
  local upper = {}
  for i = #unique, 1, -1 do
    local p = unique[i]
    while #upper >= 2
      and cross(upper[#upper - 1], upper[#upper], p) <= 0 do
      upper[#upper] = nil
    end
    upper[#upper + 1] = p
  end
  lower[#lower] = nil
  upper[#upper] = nil
  for _, p in ipairs(upper) do lower[#lower + 1] = p end
  return lower
end

-- Convex silhouette of a rectangular vertical proxy on one receiver plane.
-- It is the hull of the proxy at the first height the receiver can see and
-- at its top. One polygon means no self-overlap and no alpha accumulation
-- inside a caster, unlike projecting every face independently.
function ProjectedShadows.proxyPolygon(c, receiverY, kx, kz)
  local baseY = c.baseY or 0
  local topY = c.topY or (baseY + (c.height or 0))
  if topY <= receiverY then return {} end
  local lowY = math.max(baseY, receiverY)
  local dx0, dz0 = kx * (lowY - receiverY), kz * (lowY - receiverY)
  local dx1, dz1 = kx * (topY - receiverY), kz * (topY - receiverY)
  return convexHull({
    { c.x0 + dx0, c.z0 + dz0 }, { c.x1 + dx0, c.z0 + dz0 },
    { c.x1 + dx0, c.z1 + dz0 }, { c.x0 + dx0, c.z1 + dz0 },
    { c.x0 + dx1, c.z0 + dz1 }, { c.x1 + dx1, c.z0 + dz1 },
    { c.x1 + dx1, c.z1 + dz1 }, { c.x0 + dx1, c.z1 + dz1 },
  })
end

-- Sutherland-Hodgman against one axis-aligned cell. The four half-planes,
-- their order and every arithmetic expression below are exactly the ones the
-- closure-based version used, so the emitted vertices are bit-identical.
-- What is gone is the per-call churn: this clip runs once per receiver cell,
-- thousands of times per map, and it used to allocate six closures, four
-- result tables and one table per intersection on every one of them. That
-- allocation, not the geometry, was the bulk of a static build's CPU.
--
-- The buffers cannot be file-locals: a static build can suspend inside its
-- triangle fan (the vertex sink yields when a block fills) while the moving
-- character stream runs its own buildCPU in the same frame. Each buildCPU
-- therefore borrows one scratch set and gives it back when it finishes.
local scratchPool = {}

local function acquireScratch()
  local n = #scratchPool
  local s = scratchPool[n]
  if s then
    scratchPool[n] = nil
    s.used = 0
    return s
  end
  return { a = {}, b = {}, points = {}, used = 0 }
end

local function releaseScratch(s)
  scratchPool[#scratchPool + 1] = s
end

local function poolPoint(s, x, z)
  local n = s.used + 1
  s.used = n
  local p = s.points[n]
  if not p then
    p = {}
    s.points[n] = p
  end
  p[1], p[2] = x, z
  return p
end

local function atX(s, a, b, x)
  local d = b[1] - a[1]
  local t = math.abs(d) < 1e-9 and 0 or (x - a[1]) / d
  return poolPoint(s, x, a[2] + (b[2] - a[2]) * t)
end

local function atZ(s, a, b, z)
  local d = b[2] - a[2]
  local t = math.abs(d) < 1e-9 and 0 or (z - a[2]) / d
  return poolPoint(s, a[1] + (b[1] - a[1]) * t, z)
end

-- `axis` selects x (1) or z (2); `upper` picks `<= limit` over `>= limit`.
local function clipHalf(s, src, n, dst, axis, limit, upper, at)
  if n == 0 then return 0 end
  local m = 0
  local a = src[n]
  local ain = upper and a[axis] <= limit or (not upper) and a[axis] >= limit
  for i = 1, n do
    local b = src[i]
    local bin = upper and b[axis] <= limit or (not upper) and b[axis] >= limit
    if bin then
      if not ain then
        m = m + 1
        dst[m] = at(s, a, b, limit)
      end
      m = m + 1
      dst[m] = b
    elseif ain then
      m = m + 1
      dst[m] = at(s, a, b, limit)
    end
    a, ain = b, bin
  end
  return m
end

-- Returns the scratch buffer holding the clipped ring plus its length. Both
-- stay valid until the next clip on the same scratch set.
local function clipCell(s, poly, x0, z0, x1, z1)
  s.used = 0
  local n = clipHalf(s, poly, #poly, s.a, 1, x0, false, atX)
  n = clipHalf(s, s.a, n, s.b, 1, x1, true, atX)
  n = clipHalf(s, s.b, n, s.a, 2, z0, false, atZ)
  n = clipHalf(s, s.a, n, s.b, 2, z1, true, atZ)
  return s.b, n
end

-- Unchanged public contract: a fresh polygon of fresh points.
function ProjectedShadows.clipPolygon(poly, x0, z0, x1, z1)
  local s = acquireScratch()
  local buf, n = clipCell(s, poly, x0, z0, x1, z1)
  local out = {}
  for i = 1, n do
    out[i] = { buf[i][1], buf[i][2] }
  end
  releaseScratch(s)
  return out
end

-- Pure CPU geometry path. `receiver(tx,ty)` returns a horizontal receiver
-- height or nil. The callback receives three non-overlapping 2D points plus
-- their shared world Y; without one, a compact 3D vertex list is returned for
-- tests. Keeping the callback path 2D avoids three temporary tables per
-- triangle in both the static builder and the moving-character stream.
function ProjectedShadows.buildCPU(casters, bounds, receiver, kx, kz, emit)
  local verts = emit and nil or {}
  local scratch = acquireScratch()
  local stats = { casters = #casters, receiverTests = 0,
                  receiverHits = 0, triangles = 0, vertices = 0 }
  local function triangle(a, b, c, h)
    stats.triangles = stats.triangles + 1
    stats.vertices = stats.vertices + 3
    local y = h + ProjectedShadows.EPS
    if emit then
      emit(a, b, c, y)
    else
      verts[#verts + 1] = { a[1], y, a[2] }
      verts[#verts + 1] = { b[1], y, b[2] }
      verts[#verts + 1] = { c[1], y, c[2] }
    end
  end

  for _, c in ipairs(casters) do
    Budget.tick()
    local top = math.min(c.topY or 0, (c.baseY or 0)
                         + ProjectedShadows.MAX_CASTER_HEIGHT)
    local cc = copyCaster(c)
    cc.topY = top
    local broad = ProjectedShadows.proxyPolygon(cc, 0, kx, kz)
    if #broad >= 3 then
      local minX, maxX, minZ, maxZ
      for _, p in ipairs(broad) do
        minX = minX and math.min(minX, p[1]) or p[1]
        maxX = maxX and math.max(maxX, p[1]) or p[1]
        minZ = minZ and math.min(minZ, p[2]) or p[2]
        maxZ = maxZ and math.max(maxZ, p[2]) or p[2]
      end
      local tx0 = math.max(bounds.tx0, math.floor(minX / 8))
      local tx1 = math.min(bounds.tx1, math.floor((maxX - 1e-6) / 8))
      local ty0 = math.max(bounds.ty0, math.floor(minZ / 8))
      local ty1 = math.min(bounds.ty1, math.floor((maxZ - 1e-6) / 8))
      for ty = ty0, ty1 do
        for tx = tx0, tx1 do
          Budget.tick()
          stats.receiverTests = stats.receiverTests + 1
          local h = receiver(tx, ty)
          if h ~= nil and top > h then
            local poly = h == 0 and broad
                         or ProjectedShadows.proxyPolygon(cc, h, kx, kz)
            local clipped, m = clipCell(
              scratch, poly, tx * 8, ty * 8, tx * 8 + 8, ty * 8 + 8)
            if m >= 3 then
              stats.receiverHits = stats.receiverHits + 1
              for i = 2, m - 1 do
                triangle(clipped[1], clipped[i], clipped[i + 1], h)
              end
            end
          end
        end
      end
    end
  end
  releaseScratch(scratch)
  return verts, stats
end

-- ----------------------------------------------------------- map analysis --

local function keyOf(tx, ty)
  return (ty + 64) * 4096 + (tx + 64)
end

-- Ground-only v1: body cells whose rendered horizontal surface is the
-- y=0 walking floor. Water/void and raised top faces are intentionally not
-- receivers. Synthesised ground under buildings, props and flowers is valid.
local function receiverHeight(S, tx, ty, tw, th)
  if tx < 0 or ty < 0 or tx >= tw or ty >= th then return nil end
  local k = keyOf(tx, ty)
  if S.skip[k] and S.ground[k] ~= nil then return 0 end
  local s = S.shapeAt[k]
  if not s or not s.flat then return nil end
  if s.class == "water" or s.class == "void" then return nil end
  return 0
end

ProjectedShadows.receiverHeight = receiverHeight

local roundBounds = setmetatable({}, { __mode = "k" })
local function proxyForStamp(st)
  local b = roundBounds[st.quads]
  if not b then
    b = { minX = math.huge, maxX = -math.huge,
          minZ = math.huge, maxZ = -math.huge,
          minY = math.huge, maxY = -math.huge }
    for _, q in ipairs(st.quads or {}) do
      Budget.tick()
      for i = 1, 4 do
        local p = q[i]
        b.minX, b.maxX = math.min(b.minX, p[1]), math.max(b.maxX, p[1])
        b.minY, b.maxY = math.min(b.minY, p[2]), math.max(b.maxY, p[2])
        b.minZ, b.maxZ = math.min(b.minZ, p[3]), math.max(b.maxZ, p[3])
      end
    end
    roundBounds[st.quads] = b
  end
  if b.maxY == -math.huge then return nil end
  -- The exact hull is round; an inset rectangular footprint keeps the proxy
  -- credible without turning a tree into the full square of its cell.
  local r = (st.r or 8) * 0.78
  return { x0 = st.mx - r, x1 = st.mx + r,
           z0 = st.mz - r, z1 = st.mz + r,
           baseY = math.max(0, b.minY), topY = b.maxY, kind = "round" }
end

local EXCLUDED = {
  ground = true, water = true, waterfall = true, void = true,
  grass = true, flower = true,
  ledge = true, terrace = true, stair_e = true, stair_w = true,
  stair_down_e = true, stair_down_w = true,
}

local function collectCasters(map, S)
  local tw, th = map.def.width * 4, map.def.height * 4
  local out, kinds = {}, {}
  local function add(c)
    local h = (c.topY or 0) - (c.baseY or 0)
    if h <= 0 or c.x1 <= c.x0 or c.z1 <= c.z0 then return end
    c.topY = math.min(c.topY, (c.baseY or 0)
                     + ProjectedShadows.MAX_CASTER_HEIGHT)
    out[#out + 1] = c
    local kind = c.kind or "proxy"
    kinds[kind] = (kinds[kind] or 0) + 1
  end

  -- Buildings, detected/pinned props, fences and authored figures register
  -- one proxy while their real geometry is already being analysed.
  for _, c in ipairs(S.shadowCasters or {}) do add(copyCaster(c)) end

  -- Round trees/rocks are stored as shared template + map stamp. Scan each
  -- distinct template only once, then place a compact footprint per stamp.
  for _, st in ipairs(S.roundStamps or {}) do
    local c = proxyForStamp(st)
    if c then add(c) end
  end

  -- Volume runs carry real measured height. Merge horizontally adjacent
  -- columns with the same north/front/height into one rectangular caster.
  local runRows = {}
  local seenRun = setmetatable({}, { __mode = "k" })
  for ty = 0, th - 1 do
    for tx = 0, tw - 1 do
      Budget.tick()
      local run = S.runs[keyOf(tx, ty)]
      if run and not seenRun[run] then
        seenRun[run] = true
        local s = S.shapeAt[keyOf(tx, run.front or ty)]
        if s and not EXCLUDED[s.class] then
          local top = run.peak or run.h or s.h or 0
          local rk = table.concat({ tostring(run.north or ty),
                                    tostring(run.front or ty),
                                    tostring(roundTo(top, 16)) }, ":")
          local row = runRows[rk]
          if not row then
            row = { north = run.north or ty, front = run.front or ty,
                    top = top, xs = {} }
            runRows[rk] = row
          end
          row.xs[#row.xs + 1] = tx
        end
      end
    end
  end
  for _, row in pairs(runRows) do
    table.sort(row.xs)
    local first, last = nil, nil
    for _, tx in ipairs(row.xs) do
      if first and tx ~= last + 1 then
        add({ x0 = first * 8, x1 = (last + 1) * 8,
              z0 = row.north * 8, z1 = (row.front + 1) * 8,
              baseY = 0, topY = row.top, kind = "volume" })
        first = nil
      end
      first, last = first or tx, tx
    end
    if first then
      add({ x0 = first * 8, x1 = (last + 1) * 8,
            z0 = row.north * 8, z1 = (row.front + 1) * 8,
            baseY = 0, topY = row.top, kind = "volume" })
    end
  end

  -- Remaining authored/non-run solids (barriers, signs, rocks, low props).
  -- Greedy same-class/same-height rectangles keep caster count bounded.
  local grid, used = {}, {}
  for ty = 0, th - 1 do
    for tx = 0, tw - 1 do
      local k = keyOf(tx, ty)
      local s = S.shapeAt[k]
      if s and not S.skip[k] and not S.runs[k] and not s.flat
         and not EXCLUDED[s.class] and (s.h or 0) > 0 then
        grid[ty * tw + tx] = { class = s.class, h = s.h }
      end
    end
  end
  for ty = 0, th - 1 do
    for tx = 0, tw - 1 do
      Budget.tick()
      local i = ty * tw + tx
      local g = grid[i]
      if g and not used[i] then
        local x1 = tx
        while x1 + 1 < tw do
          local ni, ng = ty * tw + x1 + 1, grid[ty * tw + x1 + 1]
          if used[ni] or not ng or ng.class ~= g.class or ng.h ~= g.h then break end
          x1 = x1 + 1
        end
        local y1, grow = ty, true
        while grow and y1 + 1 < th do
          for x = tx, x1 do
            local ni, ng = (y1 + 1) * tw + x, grid[(y1 + 1) * tw + x]
            if used[ni] or not ng or ng.class ~= g.class or ng.h ~= g.h then
              grow = false
              break
            end
          end
          if grow then y1 = y1 + 1 end
        end
        for y = ty, y1 do
          for x = tx, x1 do used[y * tw + x] = true end
        end
        add({ x0 = tx * 8, x1 = (x1 + 1) * 8,
              z0 = ty * 8, z1 = (y1 + 1) * 8,
              baseY = 0, topY = g.h, kind = g.class })
      end
    end
  end
  return out, kinds, tw, th
end

ProjectedShadows.collectCasters = collectCasters

-- --------------------------------------------------------- GPU + caching --

local function getWhite()
  if white ~= nil then return white or nil end
  local ok, img = pcall(function()
    local data = love.image.newImageData(1, 1)
    data:setPixel(0, 0, 1, 1, 1, 1)
    local made = love.graphics.newImage(data)
    if data.release then pcall(data.release, data) end
    made:setFilter("nearest", "nearest")
    return made
  end)
  white = ok and img or false
  if not white then fail("white texture: " .. tostring(img)) end
  return white or nil
end

local function newMesh(verts, usage)
  local ok, mesh = pcall(love.graphics.newMesh, Voxel3D.FORMAT, verts,
                         "triangles", usage or "static")
  if not ok then return nil, mesh end
  return mesh
end

local function newSink()
  local verts, parts = {}, {}
  local n = 0
  local function flush()
    if #verts == 0 then return true end
    Budget.check()
    local upload = verts
    verts = {}
    local mesh, err = newMesh(upload, "static")
    upload = nil
    if not mesh then
      for _, p in ipairs(parts) do release(p) end
      return fail("static mesh allocation: " .. tostring(err))
    end
    parts[#parts + 1] = mesh
    Budget.check()
    return true
  end
  return {
    triangle = function(a, b, c, y)
      verts[#verts + 1] = { a[1], y, a[2], 0.5, 0.5, 1 }
      verts[#verts + 1] = { b[1], y, b[2], 0.5, 0.5, 1 }
      verts[#verts + 1] = { c[1], y, c[2], 0.5, 0.5, 1 }
      n = n + 3
      if #verts + 3 > ProjectedShadows.BLOCK_VERTICES then flush() end
    end,
    finish = function()
      if not flush() or #parts == 0 then return nil, n, #parts end
      return Voxel3D.meshSet(parts), n, #parts
    end,
  }
end

function ProjectedShadows.cacheKey(mapId, analysis, kx, kz)
  return table.concat({ tostring(mapId), tostring(analysis),
                        string.format("%.4f", kx),
                        string.format("%.4f", kz) }, "|")
end

function ProjectedShadows.cacheDecision(record, key)
  return not record or record.key ~= key
end

local function outdoor(map)
  local ok, Map = pcall(require, "src.world.Map")
  return ok and Map and map and map.def and Map.isOutdoor(map.def) or false
end

local function buildJob(job)
  local casters, kinds, tw, th = collectCasters(job.map, job.analysis)
  local sink = newSink()
  local _, stats = ProjectedShadows.buildCPU(
    casters, { tx0 = 0, ty0 = 0, tx1 = tw - 1, ty1 = th - 1 },
    function(tx, ty)
      return receiverHeight(job.analysis, tx, ty, tw, th)
    end,
    job.kx, job.kz, sink.triangle)
  local mesh, vertices, parts = sink.finish()
  if failed then return nil end
  stats.kinds, stats.parts = kinds, parts
  stats.vertices = vertices
  stats.vramBytes = vertices * 24
  return { key = job.key, mesh = mesh, stats = stats,
           analysis = job.analysis, kx = job.kx, kz = job.kz }
end

local function finishJob(job, ok, value)
  for i = #jobs, 1, -1 do
    if jobs[i] == job then table.remove(jobs, i); break end
  end
  if pending[job.map.id] ~= job then
    if ok and value then release(value.mesh) end
    return
  end
  pending[job.map.id] = nil
  if not ok then
    print("[warn] geometric shadow build failed for " .. tostring(job.map.id)
          .. ": " .. tostring(value))
    return
  end
  if not value then return end
  value.stats.cpuSeconds = job.cpuSeconds or 0
  value.stats.wallSeconds = clock() - (job.createdAt or clock())
  local old = cache[job.map.id]
  cache[job.map.id] = value
  if old and old.mesh ~= value.mesh then release(old.mesh) end
  totalBuilds = totalBuilds + 1
  print(string.format(
    "[G-SHADOW] %s: %d casters, %d vertices, %d triangles, "
    .. "%d draws, %.3f ms CPU, %.1f KiB",
    tostring(job.map.id), value.stats.casters or 0,
    value.stats.vertices or 0, value.stats.triangles or 0,
    value.stats.parts or 0, (value.stats.cpuSeconds or 0) * 1000,
    (value.stats.vramBytes or 0) / 1024))
end

-- `urgent` marks the map the scene is actually drawn from. Its shadows are
-- part of the frame the player is looking at, so they may not wait for the
-- background conditions an off-screen neighbour is content with.
function ProjectedShadows.request(map, urgent)
  if not ProjectedShadows.enabled() or not outdoor(map) then return nil end
  local analysis = Structures.forMap(map)
  local kx, kz = ProjectedShadows.direction()
  local key = ProjectedShadows.cacheKey(map.id, analysis, kx, kz)
  local rec = cache[map.id]
  if rec and rec.key == key then return rec end
  local job = pending[map.id]
  if not job or job.key ~= key then
    if job then job.cancelled = true end
    job = { map = map, analysis = analysis, kx = kx, kz = kz, key = key,
            createdAt = clock(), cpuSeconds = 0,
            urgent = urgent and true or false }
    pending[map.id] = job
    jobs[#jobs + 1] = job
  elseif urgent then
    -- The per-frame draw pass requests the same map without the flag; a
    -- promotion is never taken back for the life of the job.
    job.urgent = true
  end
  -- Keep the previous sun/geometry until the replacement publishes. Fixed
  -- GOLDEN never takes this path after its first build.
  return rec
end

function ProjectedShadows.requestVisible(state, neighborMeshes)
  if not (ProjectedShadows.enabled() and state and state.map) then return end
  ProjectedShadows.request(state.map, true)
  for i, nb in ipairs(state.neighbors or {}) do
    if neighborMeshes and neighborMeshes[i]
       and state._dramaticVisibleNeighbors
       and state._dramaticVisibleNeighbors[i] then
      ProjectedShadows.request(nb.map)
    end
  end
end

-- An anticipated outdoor destination: queued from the interior the player is
-- still walking around in, so that the door fade hands over a map whose
-- shadows are already cached. It is not visible, so it may not outrank the
-- current map -- but it must not stall while the player walks either, which
-- is exactly the defect the visible-map fix removed. Same reasoning, and the
-- same shape, as ChunkMesher's speculative exterior prewarm.
function ProjectedShadows.prewarm(map, opts)
  if not ProjectedShadows.enabled() or not map or not outdoor(map) then
    return nil
  end
  opts = opts or {}
  local retain = math.max(0, math.floor(tonumber(opts.retainLiveChanges) or 0))
  if retain > 0 then
    prewarmRetain[map.id] = math.max(prewarmRetain[map.id] or 0, retain)
  end
  local rec = ProjectedShadows.request(map)
  local job = pending[map.id]
  if job and not job.urgent then job.prewarm = true end
  return rec
end

-- The current map is presentation-critical work and gets a slice on the
-- scale the terrain mesher already spends on its own urgent jobs (0.002)
-- and on a covered frame (0.006). A destination prewarm gets a smaller
-- bounded slice than ChunkMesher's own 0.004 -- the two can share an
-- interior frame -- and everything else keeps the v13 background budget
-- exactly. The pump still runs only when ChunkMesher reports no urgent
-- terrain job, so terrain publication continues to win outright.
ProjectedShadows.URGENT_SLICE = 0.003
ProjectedShadows.URGENT_COVERED_SLICE = 0.006
ProjectedShadows.PREWARM_SLICE = 0.003
ProjectedShadows.PREWARM_COVERED_SLICE = 0.006
ProjectedShadows.BACKGROUND_SLICE = 0.0005
ProjectedShadows.BACKGROUND_COVERED_SLICE = 0.002

local function pickJob(allowBackground)
  local warm = nil
  for i = 1, #jobs do
    local job = jobs[i]
    if job.urgent then return job end
    if not warm and job.prewarm then warm = job end
  end
  if warm then return warm end
  if allowBackground == false then return nil end
  return jobs[1]
end

function ProjectedShadows.pump(covered, scale, allowBackground)
  if failed or not ProjectedShadows.enabled() or #jobs == 0 then return end
  scale = math.max(0, math.min(1, tonumber(scale) or 1))
  if scale <= 0 then return end
  local job = pickJob(allowBackground)
  if not job then return end
  local slice
  if job.urgent then
    slice = (covered and ProjectedShadows.URGENT_COVERED_SLICE
             or ProjectedShadows.URGENT_SLICE) * scale
  elseif job.prewarm then
    slice = (covered and ProjectedShadows.PREWARM_COVERED_SLICE
             or ProjectedShadows.PREWARM_SLICE) * scale
  else
    slice = (covered and ProjectedShadows.BACKGROUND_COVERED_SLICE
             or ProjectedShadows.BACKGROUND_SLICE) * scale
  end
  local deadline = clock() + slice
  local t0 = clock()
  while job and clock() < deadline do
    if job.cancelled then
      finishJob(job, true, nil)
    else
      if not job.co then
        job.co = coroutine.create(function() return buildJob(job) end)
      end
      Budget.begin(job.co, math.max(0, deadline - clock()))
      local resumeAt = clock()
      local ok, value = coroutine.resume(job.co)
      job.cpuSeconds = (job.cpuSeconds or 0) + (clock() - resumeAt)
      Budget.finish()
      if not ok then
        finishJob(job, false, value)
      elseif coroutine.status(job.co) == "dead" then
        finishJob(job, true, value)
      else
        break
      end
    end
    job = pickJob(allowBackground)
  end
  maxPump = math.max(maxPump, clock() - t0)
end

function ProjectedShadows.drawMap(map, ox, oz)
  local rec = ProjectedShadows.request(map)
  local tex = getWhite()
  if not (rec and rec.mesh and tex) then return end
  local model = ((ox or 0) ~= 0 or (oz or 0) ~= 0)
                and Mat4.translate(ox or 0, 0, oz or 0) or nil
  local ok, err = Voxel3D.drawProjectedShadow(rec.mesh, tex, model)
  if not ok then fail("static mesh draw: " .. tostring(err)) end
end

local function dynamicKey(posed, kx, kz)
  local out = { string.format("%.4f,%.4f", kx, kz) }
  for _, p in ipairs(posed or {}) do
    out[#out + 1] = table.concat({
      tostring(p.map and p.map.id or "?"),
      string.format("%.3f", p.px or 0), string.format("%.3f", p.py or 0),
      string.format("%.3f", p.gh or 0), string.format("%.3f", p.lift or 0),
      tostring(p.ox or 0), tostring(p.oz or 0),
    }, ":")
  end
  return table.concat(out, "|")
end

ProjectedShadows.dynamicKey = dynamicKey

local function ensureDynamicMesh(n)
  if n <= dynCapacity and dynMesh then return true end
  local cap = 96
  while cap < n do cap = cap * 2 end
  local ok, mesh = pcall(love.graphics.newMesh, Voxel3D.FORMAT, cap,
                         "triangles", "stream")
  if not ok then return fail("dynamic mesh allocation: " .. tostring(mesh)) end
  release(dynMesh)
  dynMesh, dynCapacity = mesh, cap
  return true
end

local function rebuildDynamic(posed, kx, kz)
  local written = 0
  local function put(x, y, z)
    written = written + 1
    local v = dynVerts[written]
    if not v then
      v = {}
      dynVerts[written] = v
    end
    v[1], v[2], v[3] = x, y, z
    v[4], v[5], v[6] = 0.5, 0.5, 1
  end
  for _, p in ipairs(posed or {}) do
    local map = p.map
    if map and outdoor(map) then
      local S = Structures.forMap(map)
      local tw, th = map.def.width * 4, map.def.height * 4
      local ox, oz = p.ox or 0, p.oz or 0
      local px, pz = (p.px or 0) - ox, (p.py or 0) - oz
      local lift = math.max(0, p.lift or 0)
      local caster = {
        x0 = px + 4, x1 = px + 12, z0 = pz + 6, z1 = pz + 10,
        baseY = (p.gh or 0) + lift,
        topY = (p.gh or 0) + lift + 16,
        kind = "character",
      }
      ProjectedShadows.buildCPU(
        { caster }, { tx0 = 0, ty0 = 0, tx1 = tw - 1, ty1 = th - 1 },
        function(tx, ty) return receiverHeight(S, tx, ty, tw, th) end,
        kx, kz,
        function(a, b, c, y)
          put(a[1] + ox, y, a[2] + oz)
          put(b[1] + ox, y, b[2] + oz)
          put(c[1] + ox, y, c[2] + oz)
        end)
    end
  end
  dynCount = written
  if dynCount == 0 then return true end
  if not ensureDynamicMesh(dynCount) then return false end
  local ok, err = pcall(function()
    dynMesh:setVertices(dynVerts, 1, dynCount)
    dynMesh:setDrawRange(1, dynCount)
  end)
  if not ok then return fail("dynamic mesh upload: " .. tostring(err)) end
  return true
end

function ProjectedShadows.drawDynamic(posed)
  if not ProjectedShadows.enabled() then return end
  local kx, kz = ProjectedShadows.direction()
  local sig = dynamicKey(posed, kx, kz)
  if sig ~= dynSignature then
    if not rebuildDynamic(posed, kx, kz) then return end
    dynSignature = sig
  end
  local tex = getWhite()
  if dynMesh and dynCount > 0 and tex then
    local ok, err = Voxel3D.drawProjectedShadow(dynMesh, tex)
    if not ok then fail("dynamic mesh draw: " .. tostring(err)) end
  end
end

-- A destination prewarmed from inside a house is by definition not in the
-- live set while it is being built: without a bounded hold, the next
-- neighbourhood change would free exactly the work the prewarm exists to do.
-- The hold is the same bounded one the terrain prewarm already uses -- it
-- clears the moment the map becomes live, and counts down otherwise, so a
-- player who takes a different door reverts to ordinary eviction.
function ProjectedShadows.setLive(nextLive)
  live = nextLive or {}
  for id, rec in pairs(cache) do
    if not live[id] and (prewarmRetain[id] or 0) <= 0 then
      release(rec.mesh)
      cache[id] = nil
    end
  end
  for id, job in pairs(pending) do
    if not live[id] and (prewarmRetain[id] or 0) <= 0 then
      job.cancelled = true
      pending[id] = nil
    end
  end
  for id, count in pairs(prewarmRetain) do
    if live[id] or count <= 0 then
      prewarmRetain[id] = nil
    else
      prewarmRetain[id] = count - 1
    end
  end
end

function ProjectedShadows.invalidate(mapId)
  if mapId then
    prewarmRetain[mapId] = nil
    local rec = cache[mapId]
    if rec then release(rec.mesh); cache[mapId] = nil end
    if pending[mapId] then pending[mapId].cancelled = true; pending[mapId] = nil end
  else
    for _, rec in pairs(cache) do release(rec.mesh) end
    cache = {}
    for _, job in pairs(pending) do job.cancelled = true end
    pending = {}
    jobs = {}
    prewarmRetain = {}
  end
  dynSignature = nil
end

function ProjectedShadows.metrics()
  local maps, casters, vertices, triangles, parts, vram = 0, 0, 0, 0, 0, 0
  local records = {}
  for id, rec in pairs(cache) do
    local s = rec.stats or {}
    maps = maps + 1
    casters = casters + (s.casters or 0)
    vertices = vertices + (s.vertices or 0)
    triangles = triangles + (s.triangles or 0)
    parts = parts + (s.parts or 0)
    vram = vram + (s.vramBytes or 0)
    records[id] = s
  end
  return { maps = maps, casters = casters, vertices = vertices,
           triangles = triangles, drawCalls = parts + (dynCount > 0 and 1 or 0),
           vramBytes = vram + dynCapacity * 24, dynamicVertices = dynCount,
           pending = #jobs, builds = totalBuilds, maxPump = maxPump,
           records = records }
end

return ProjectedShadows
