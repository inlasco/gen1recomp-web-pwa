-- Dramatic Shape Web/iPhone compatibility shim.
-- OpenXR in the upstream mod is Windows/LuaJIT-only. Safari/love.js has
-- neither Win32 OpenXR nor LuaJIT FFI, so VR is deliberately unavailable.
-- The facade preserves the interface expected by main.lua and other modules.

local V = ...
local ModSetting = V.require("ModSetting")

local VR = {}

VR.setting = ModSetting.new("vr", "VR", { false, true }, { "OFF", "ON" })
VR.smoothTurn = ModSetting.new("smoothturn", "SMOOTH TURN",
                               { false, true }, { "OFF", "ON" })
VR.paletteFor = nil
VR.cycleVoxel = nil

function VR.supported() return false end
function VR.enabled() return false end
function VR.active() return false end
function VR.status() return "unsupported on Web/iPhone" end
function VR.update(_) end
function VR.mirror(_, _) return nil end
function VR.invalidate() end

return VR
