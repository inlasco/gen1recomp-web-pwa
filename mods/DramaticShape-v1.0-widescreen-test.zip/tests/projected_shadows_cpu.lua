-- Pure CPU invariants for lib/ProjectedShadows.lua. No LOVE window or GPU.

love = {
  system = { getOS = function() return "Web" end },
  graphics = {}, image = {}, timer = { getTime = os.clock },
}

-- Lua 5.1/LuaJIT (the target) exposes atan2; Fengari uses the Lua 5.3
-- two-argument atan form.
math.atan2 = math.atan2 or function(y, x) return math.atan(y, x) end

package.preload["src.render.PaletteFX"] = function()
  return { effectiveColors = function(c) return c end }
end
package.preload["src.world.Map"] = function()
  return { isOutdoor = function(def) return def and def.outdoor == true end }
end

local function setting(default)
  return {
    get = function() return default end,
    read = function() return 1 end,
    row = function() return {} end,
    schema = function() return {} end,
  }
end

local modules = {}
modules.ModSetting = { new = function(_, _, values) return setting(values[1]) end }
modules.Voxel3D = {
  FORMAT = {}, releaseMesh = function() end, meshSet = function(p) return p end,
}
modules.Mat4 = { translate = function(x, y, z) return { x, y, z } end }
modules.Structures = {}
modules.BuildBudget = { tick = function() end, check = function() end,
                        begin = function() end, finish = function() end }
modules.ShadowMap = { KX = -0.85, KZ = -0.55 }

local V = {}
function V.require(name) return assert(modules[name], "missing stub " .. name) end

local dayChunk = assert(loadfile("lib/DayNight.lua"))
modules.DayNight = dayChunk(V)
local psChunk = assert(loadfile("lib/ProjectedShadows.lua"))
local PS = psChunk(V)
local DayNight = modules.DayNight

local passed, total = 0, 0
local function test(name, fn)
  total = total + 1
  local ok, detail = pcall(fn)
  if not ok then
    io.stderr:write("FAIL " .. name .. ": " .. tostring(detail) .. "\n")
    os.exit(1)
  end
  passed = passed + 1
  print("PASS " .. name .. (detail and (" " .. detail) or ""))
end

local function near(a, b, eps)
  eps = eps or 1e-9
  assert(math.abs(a - b) <= eps,
         string.format("%.12f != %.12f", a, b))
end

local function samePoly(a, b, dx, dz)
  assert(#a == #b)
  local drift = 0
  for i = 1, #a do
    drift = math.max(drift, math.abs((b[i][1] - a[i][1]) - (dx or 0)),
                     math.abs((b[i][2] - a[i][2]) - (dz or 0)))
  end
  return drift
end

local caster = { x0 = 32, x1 = 48, z0 = 40, z1 = 48,
                 baseY = 0, topY = 32, kind = "fixture" }
local goldenKX, goldenKZ = DayNight.shearAt(DayNight.T.golden)

test("camera_invariance", function()
  local reference = PS.proxyPolygon(caster, 0, goldenKX, goldenKZ)
  local cameras = { { 0, 0 }, { 160, 144 }, { -512, 2048 }, { 0.25, -0.75 } }
  local maxDrift = 0
  for _ = 1, #cameras do
    -- There is intentionally no camera argument to the projection function.
    local again = PS.proxyPolygon(caster, 0, goldenKX, goldenKZ)
    maxDrift = math.max(maxDrift, samePoly(reference, again, 0, 0))
  end
  near(maxDrift, 0)
  return string.format("max_world_vertex_drift=%.12f", maxDrift)
end)

test("direction_and_height", function()
  local lengths = {}
  for i, h in ipairs({ 8, 16, 32 }) do
    local p = PS.projectPoint({ 10, h, 20 }, 0, goldenKX, goldenKZ)
    lengths[i] = math.sqrt((p[1] - 10)^2 + (p[3] - 20)^2)
  end
  assert(lengths[1] > 0 and lengths[2] > lengths[1]
         and lengths[3] > lengths[2])
  near(lengths[2] / lengths[1], 2, 1e-9)
  near(lengths[3] / lengths[1], 4, 1e-9)
  return string.format("lengths=%.6f,%.6f,%.6f", lengths[1], lengths[2], lengths[3])
end)

test("golden_source", function()
  local qx, qz = PS.quantizeDirection(goldenKX, goldenKZ)
  local bx, bz = DayNight.shearAt(DayNight.T.golden)
  near(goldenKX, bx)
  near(goldenKZ, bz)
  assert(qx * goldenKX >= 0 and qz * goldenKZ >= 0)
  return string.format("exact_shear=(%.9f,%.9f) quantized=(%.4f,%.4f)",
                       goldenKX, goldenKZ, qx, qz)
end)

test("receiver_clipping", function()
  local valid = { ["1:1"] = true, ["2:1"] = true, ["2:2"] = true,
                  ["3:2"] = true }
  local verts, stats = PS.buildCPU(
    { { x0 = 10, x1 = 18, z0 = 10, z1 = 18,
        baseY = 0, topY = 18 } },
    { tx0 = 0, ty0 = 0, tx1 = 4, ty1 = 4 },
    function(tx, ty) return valid[tx .. ":" .. ty] and 0 or nil end,
    0.75, 0.35)
  assert(#verts > 0)
  local outside = 0
  for _, v in ipairs(verts) do
    local inside = false
    for key in pairs(valid) do
      local tx, ty = key:match("^(%-?%d+):(%-?%d+)$")
      tx, ty = tonumber(tx), tonumber(ty)
      if v[1] >= tx * 8 - 1e-8 and v[1] <= tx * 8 + 8 + 1e-8
         and v[3] >= ty * 8 - 1e-8 and v[3] <= ty * 8 + 8 + 1e-8 then
        inside = true
        break
      end
    end
    if not inside then outside = outside + 1 end
  end
  assert(outside == 0)
  return string.format("vertices=%d receiver_hits=%d outside=%d",
                       #verts, stats.receiverHits, outside)
end)

test("neighbor_offsets", function()
  local base = PS.proxyPolygon(caster, 0, goldenKX, goldenKZ)
  local offsets = { center = { 0, 0 }, left = { -320, 0 },
                    right = { 320, 0 }, up = { 0, -288 },
                    down = { 0, 288 } }
  local maxError = 0
  for _, off in pairs(offsets) do
    local shifted = PS.proxyPolygon(PS.offsetCaster(caster, off[1], off[2]),
                                    0, goldenKX, goldenKZ)
    maxError = math.max(maxError,
                        samePoly(base, shifted, off[1], off[2]))
  end
  near(maxError, 0)
  return string.format("center_left_right_up_down_error=%.12f", maxError)
end)

test("z_offset", function()
  assert(PS.EPS > 0 and PS.EPS < 0.5)
  local verts = PS.buildCPU(
    { caster }, { tx0 = 0, ty0 = 0, tx1 = 20, ty1 = 20 },
    function() return 0 end, goldenKX, goldenKZ)
  local mismatch = 0
  for _, v in ipairs(verts) do
    if math.abs(v[2] - PS.EPS) > 1e-12 then mismatch = mismatch + 1 end
  end
  assert(mismatch == 0)
  return string.format("eps=%.2f mismatched_vertices=%d", PS.EPS, mismatch)
end)

test("static_cache", function()
  local analysis = {}
  local key = PS.cacheKey("PALLET_TOWN", analysis, 1.0, 0.5)
  local record, rebuilds = nil, 0
  local function request(k)
    if PS.cacheDecision(record, k) then
      rebuilds = rebuilds + 1
      record = { key = k }
    end
  end
  request(key)
  request(key)
  assert(rebuilds == 1)
  request(PS.cacheKey("PALLET_TOWN", analysis, 1.0625, 0.5))
  assert(rebuilds == 2)
  request(PS.cacheKey("PALLET_TOWN", {}, 1.0625, 0.5))
  assert(rebuilds == 3)
  return "same_state_rebuilds=1 sun_change=2 geometry_change=3"
end)

test("synthetic_budget", function()
  local casters = {
    { x0 = 96, x1 = 208, z0 = 64, z1 = 136, baseY = 0, topY = 48 },
    { x0 = 320, x1 = 472, z0 = 80, z1 = 176, baseY = 0, topY = 56 },
  }
  for i = 0, 7 do
    casters[#casters + 1] = { x0 = 16 + i * 40, x1 = 30 + i * 40,
                              z0 = 208, z1 = 222, baseY = 0, topY = 24 }
  end
  for i = 0, 11 do
    casters[#casters + 1] = { x0 = 64 + i * 16, x1 = 72 + i * 16,
                              z0 = 280, z1 = 286, baseY = 0, topY = 16 }
  end
  for i = 0, 2 do
    casters[#casters + 1] = { x0 = 240 + i * 24, x1 = 248 + i * 24,
                              z0 = 224, z1 = 232, baseY = 0, topY = 12 }
  end
  local t0 = os.clock()
  local verts, stats = PS.buildCPU(
    casters, { tx0 = 0, ty0 = 0, tx1 = 79, ty1 = 71 },
    function() return 0 end, goldenKX, goldenKZ)
  local elapsed = os.clock() - t0
  assert(#casters == 25 and #verts == stats.vertices)
  return string.format(
    "casters=%d vertices=%d triangles=%d vram_bytes=%d cpu_s=%.6f",
    #casters, stats.vertices, stats.triangles, stats.vertices * 24, elapsed)
end)

print(string.format("RESULT %d/%d CPU invariants passed", passed, total))
