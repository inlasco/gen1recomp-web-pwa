# Adaptation Web/iPhone v13

Cette variante conserve le runtime WebGL1 de Gen1Recomp Web v10. Elle ne
modifie ni `love.js` ni `love.wasm`.

Réglages initiaux sûrs : VOXEL OFF, 3D-BTL OFF, WATER OFF, AA OFF, T-SHIFT
OFF, V-CURVE OFF, V-GRID OFF, G-SHADOW OFF et VR OFF. Pour le test minimal,
activer volontairement VOXEL 15 et laisser tous les autres réglages à OFF.

Le terrain Web est construit en blocs non indexés bornés de 2 046 sommets
(49 104 octets). Les Mesh produits
ne deviennent visibles qu'une fois la carte entière prête. Safari utilise le
depth buffer interne WebGL1; aucune depth texture lisible et aucune shadow map
1024/1536/2048 ne sont créées sur Web. Une erreur GPU désactive la 3D pour la
session et rend immédiatement la main au rendu 2D classique.

La v12 protège l'audio love.js : buffers Web de 1 024 échantillons, réserve
cible de 16 buffers, maillage suspendu lorsque cette réserve est basse et
effets d'attaque préchauffés par tranches pendant la transition. Les sprites
de combat réutilisent leur ImageData CPU sur Web et l'arène calculée avant la
transition est mise en cache pour la position exacte du joueur.


## v13 : priorité au temps matériel iPhone

La v13 conserve WebGL1/Multi-Mesh et cible les causes mesurées sur Safari :
RAF doublement cadencé par un sleep Lua, construction froide complète avant
publication et meshing de voisins lointains pendant la marche. La réduction des
stalls et du coût Bit vise aussi à stabiliser le producteur audio principal. Les réglages 3D restent OFF par
défaut ; VOXEL 50 reste un choix volontaire.


## v13.1 : première sortie de la maison

Le seul hotfix v13.1 anticipe le cache froid de `PALLET_TOWN` lorsque VOXEL est
déjà actif dans la maison de départ. Le BODY de Pallet est construit
coopérativement en arrière-plan avant la porte, avec priorité inférieure à tout
mesh réellement courant ou à une vraie destination de warp et avec le même
garde-fou de réserve audio. Le cache peut traverser uniquement le passage
`REDS_HOUSE_2F` -> `REDS_HOUSE_1F`; il redevient ensuite soumis aux règles
d’éviction v13. Aucun autre lieu n’est préchauffé.


## Test ombres géométriques projetées

`G-SHADOW` est expérimental et reste `OFF` par défaut. Sur Safari/iPhone :

1. sélectionner `DAYTIME = GOLDEN` ;
2. activer `VOXEL` au niveau déjà validé ;
3. passer `G-SHADOW` de `OFF` à `ON` ;
4. attendre immobile un bref instant pour la construction coopérative des
   ombres statiques, puis marcher horizontalement et verticalement.

Le système projette des proxies géométriques monde sur les seules cellules de
sol horizontales valides. Il couvre les bâtiments, volumes, barrières,
arbres/rochers, props, joueur et NPC. Les fleurs ne sont ni casters ni
modifiées. Les cartes voisines réutilisent exactement leurs offsets monde.

Ce chemin ne crée aucune ShadowMap, depth map, texture de profondeur, Canvas
d’ombre, passe FBO, PCF ni readback. `ShadowMap.available()` reste faux sur Web.
Les combats conservent exclusivement leur pipeline v13.1. Une erreur propre à
ce chemin expérimental le désactive seule pour la session, sans désactiver le
rendu voxel.
